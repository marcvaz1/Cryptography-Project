#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <cmath>
#include <Windows.h>
using namespace std;
int converter(char);
int converter1(int);

int main() {
	string in, temp;
	string abc;
	ifstream inFile;
	ofstream outFile;
	string filename;
	while (true) {
		cout << "Encrypt or Decrypt ['e' or 'd']: ";
		cin >> abc;
		cin.clear();
		cin.ignore(INT_MAX, '\n');
		while (cin.fail()) {
			cin.clear();
			cin.ignore(INT_MAX, '\n');
			cout << "Please type 'e' or 'd': ";
			cin >> abc;
		}
		while (abc != "e" && abc != "E" && abc != "d"&& abc != "D") {
			if (cin.fail()) {
				cin.clear();
				cin.ignore(INT_MAX, '\n');
			}
			cout << "Please type ['e' or 'd']: ";
			cin >> abc;
		}
		if (abc == "e" || abc == "E") {
			cout << endl << "Please type the message that you want to encrypt: " << endl;
			getline(cin, in);
			cout << endl << "Encrypting";
			Sleep(300);
			cout << ".";
			Sleep(300);
			cout << ".";
			Sleep(300);
			cout << "." << endl;
			cout << endl << "Enter the filename (_______.txt) to store encrypted text and key: ";
			cin >> filename;
			outFile.open(filename + ".txt");
			while (in.size() % 3 != 0)
				in = in + '^';
			int z[3][3] = {};
			srand(time(NULL));
			int det = 0;
			while (det == 0)
				for (int s = 0; s < 3; s++) {
					for (int i = 0; i < 3; i++) {
						z[s][i] = (rand() % 100 + 1);
					}
					det = (z[0][0] * z[1][1] * z[2][2] + z[0][1] * z[1][2] * z[2][0] + z[0][2] * z[1][0] * z[2][1]) - (z[0][2] * z[1][1] * z[2][0] + z[0][1] * z[1][0] * z[2][2] + z[0][0] * z[1][2] * z[2][1]); // Discriminant calculator
				}
			outFile << "Key:" << endl;
			outFile << z[0][0] << ' ' << z[0][1] << ' ' << z[0][2] << endl;
			outFile << z[1][0] << ' ' << z[1][1] << ' ' << z[1][2] << endl;
			outFile << z[2][0] << ' ' << z[2][1] << ' ' << z[2][2] << endl << endl;
			int b = in.size();
			for (int d = 0; d < b; d += 3) {
				int c[3];
				int f = 0;
				while (f < 3) {
					c[f] = z[f][0] * converter(in[d]) + z[f][1] * converter(in[d + 1]) + z[f][2] * converter(in[d + 2]);

					if (f == 2)
						outFile << setw(5) << setfill(' ') << c[f];
					else outFile << setw(5) << setfill(' ') << c[f] << endl;
					f++;
				}
				outFile << endl << endl;
			}

			outFile.close();
			cout << endl;
		}
		else {
			string file;
			cout << endl << "Enter filename (_______.txt) to decrypt: ";
			cin >> file;
			cout << endl << "Decrypting";
			Sleep(300);
			cout << ".";
			Sleep(300);
			cout << ".";
			Sleep(300);
			cout << "." << endl;
			inFile.open(file + ".txt");
			double x[3][3], term[3], y[3];
			string out = "";
			inFile >> temp;
			inFile >> x[0][0] >> x[1][0] >> x[2][0] >> x[0][1] >> x[1][1] >> x[2][1] >> x[0][2] >> x[1][2] >> x[2][2];
			double det = (x[0][0] * x[1][1] * x[2][2] + x[0][1] * x[1][2] * x[2][0] + x[0][2] * x[1][0] * x[2][1]) - (x[0][2] * x[1][1] * x[2][0] + x[0][1] * x[1][0] * x[2][2] + x[0][0] * x[1][2] * x[2][1]);
			double a1[3][3] = {};
			a1[0][0] = (1.0 / det)*(x[1][1] * x[2][2] - x[1][2] * x[2][1]);
			a1[0][1] = (-1.0 / det)*(x[1][0] * x[2][2] - x[1][2] * x[2][0]);
			a1[0][2] = (1.0 / det)*(x[1][0] * x[2][1] - x[1][1] * x[2][0]);
			a1[1][0] = (-1.0 / det)*(x[0][1] * x[2][2] - x[0][2] * x[2][1]);
			a1[1][1] = (1.0 / det)*(x[0][0] * x[2][2] - x[0][2] * x[2][0]);
			a1[1][2] = (-1.0 / det)*(x[0][0] * x[2][1] - x[0][1] * x[2][0]);
			a1[2][0] = (1.0 / det)*(x[0][1] * x[1][2] - x[0][2] * x[1][1]);
			a1[2][1] = (-1.0 / det)*(x[0][0] * x[1][2] - x[0][2] * x[1][0]);
			a1[2][2] = (1.0 / det)*(x[0][0] * x[1][1] - x[0][1] * x[1][0]);
			int counter = 0;
			while (!inFile.eof()) {
				inFile >> term[0] >> term[1] >> term[2];
				for (int i = 0; i < 3; i++) {
					double fa = a1[i][0] * term[0] + a1[i][1] * term[1] + a1[i][2] * term[2];
					if (fa < 0) {
						y[i] = int(fa - 0.5);
					}
					else {
						y[i] = int(fa + 0.5);
					}
					char s = converter1(y[i]);
					out += s;
					counter++;
				}
			}
			out.erase(out.end() - 3, out.end());
			for (int a = out.size() - 1; a >= out.size() - 4; a--) {
				if (out[a] == '^') {
					out.erase(out.end() - 1);
				}
			}
			cout << "\nDecrypted message: \n";
			for (int i = 0; i < out.length(); ++i) {
				cout << out[i];
				Sleep(75);
			}
			cout << endl << endl;
			inFile.close();
			
		}
	}
}
int converter(char z) {
	int val;
	if (z != ' ')
		val = static_cast<int>(z) - 65;
	else val = 26;
	return val;
}
int converter1(int b) {
	char val;
	if (b != 26) {
		val = char(b + 65);
	}
	else val = ' ';
	return val;
}